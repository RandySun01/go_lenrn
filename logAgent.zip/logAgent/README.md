# logAgent

``` 
问题
PS G:\goproject\go\logAgent> git pull origin main
From https://github.com/RandySun01/logAgent
 * branch            main       -> FETCH_HEAD
fatal: refusing to merge unrelated histories
解决
git pull --allow-unrelated-histories